﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_follow : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform playerTank;

    private void FixedUpdate()
    {
        transform.position = new Vector3(playerTank.position.x, playerTank.position.y, transform.position.z);
    }
}
